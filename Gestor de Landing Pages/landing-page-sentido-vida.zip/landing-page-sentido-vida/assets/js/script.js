// ===================================
// VARIABLES GLOBALES
// ===================================

let currentWeek = 1;
let weeksData = [];

// ===================================
// CARGAR DATOS JSON
// ===================================

async function loadData() {
    try {
        const response = await fetch('data.json');
        const data = await response.json();
        weeksData = data.weeks;
        initializeApp();
    } catch (error) {
        console.error('Error cargando datos:', error);
        showErrorMessage('Error al cargar los datos. Por favor, recarga la página.');
    }
}

// ===================================
// INICIALIZAR APP
// ===================================

function initializeApp() {
    // Recuperar semana guardada del localStorage
    const savedWeek = localStorage.getItem('currentWeek');
    if (savedWeek) {
        currentWeek = parseInt(savedWeek);
    }

    // Actualizar UI
    updateThemeDisplay();
    setupEventListeners();
    
    // Verificar si es la primera visita
    if (!localStorage.getItem('visited')) {
        localStorage.setItem('visited', 'true');
        showWelcomeMessage();
    }
}

// ===================================
// ACTUALIZAR TEMA SEMANAL
// ===================================

function updateThemeDisplay() {
    const week = weeksData[currentWeek - 1];
    
    if (!week) return;

    // Actualizar números
    document.getElementById('weekNumber').textContent = currentWeek;
    document.getElementById('weekDisplay').textContent = `Semana ${currentWeek}`;
    document.getElementById('weekSlider').value = currentWeek;

    // Actualizar contenido
    document.getElementById('quarterBadge').textContent = week.quarter;
    document.getElementById('themeTitle').textContent = week.title;
    document.getElementById('themeSubtitle').textContent = week.subtitle;
    document.getElementById('themeDescription').textContent = week.description;
    document.getElementById('themeCTA').textContent = week.cta;

    // Actualizar puntos clave
    const keyPointsList = document.getElementById('keyPointsList');
    keyPointsList.innerHTML = '';
    week.keyPoints.forEach(point => {
        const li = document.createElement('li');
        li.textContent = point;
        keyPointsList.appendChild(li);
    });

    // Actualizar imagen (placeholder con emoji)
    const imageEmojis = ['🧠', '👨‍👩‍👧‍👦', '💼', '💪', '🍷', '🏥', '⚖️', '🏘️', '🔬', '👶', '❤️', '🤝', '🚬', '💬', '🧩', '💊', '🌿', '🎯', '💰', '🧠', '🔥', '👥', '😔', '🎲', '💉', '🚫', '💔', '😢', '🔮', '👫', '📈', '💼', '💊', '🤐', '⚔️', '🩹', '🥗', '🎮', '😭', '🆘', '🧘', '🔀', '🤝', '💪', '🎭', '🎊', '🏆', '🌈', '🎨', '❤️', '🙏', '🌟'];
    const emoji = imageEmojis[currentWeek - 1] || '🌟';
    document.getElementById('themeImage').textContent = emoji;

    // Guardar semana actual
    localStorage.setItem('currentWeek', currentWeek);

    // Animar cambio
    animateThemeChange();
}

function animateThemeChange() {
    const themeMain = document.querySelector('.theme-main');
    themeMain.style.opacity = '0.5';
    setTimeout(() => {
        themeMain.style.opacity = '1';
    }, 100);
}

// ===================================
// EVENT LISTENERS
// ===================================

function setupEventListeners() {
    // Botones de navegación
    document.getElementById('prevWeek').addEventListener('click', () => {
        if (currentWeek > 1) {
            currentWeek--;
            updateThemeDisplay();
        }
    });

    document.getElementById('nextWeek').addEventListener('click', () => {
        if (currentWeek < 52) {
            currentWeek++;
            updateThemeDisplay();
        }
    });

    // Slider
    document.getElementById('weekSlider').addEventListener('input', (e) => {
        currentWeek = parseInt(e.target.value);
        updateThemeDisplay();
    });

    // Menú móvil
    document.getElementById('menuToggle').addEventListener('click', toggleMobileMenu);
    
    // Cerrar menú al hacer clic en un link
    document.querySelectorAll('.mobile-menu .nav-link').forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });

    // Formulario de contacto
    document.getElementById('contactForm').addEventListener('submit', handleFormSubmit);

    // Teclas de teclado para navegación
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft' && currentWeek > 1) {
            currentWeek--;
            updateThemeDisplay();
        } else if (e.key === 'ArrowRight' && currentWeek < 52) {
            currentWeek++;
            updateThemeDisplay();
        }
    });
}

// ===================================
// MENÚ MÓVIL
// ===================================

function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    mobileMenu.classList.toggle('active');
}

function closeMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    mobileMenu.classList.remove('active');
}

// ===================================
// FORMULARIO DE CONTACTO
// ===================================

function handleFormSubmit(e) {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    // Validar
    if (!name || !email || !message) {
        showErrorMessage('Por favor completa todos los campos');
        return;
    }

    // Crear mensaje para WhatsApp
    const whatsappMessage = `Hola, me llamo ${name}. Mi email es ${email}. Mensaje: ${message}`;
    const encodedMessage = encodeURIComponent(whatsappMessage);
    const whatsappUrl = `https://wa.me/3331962135?text=${encodedMessage}`;

    // Abrir WhatsApp
    window.open(whatsappUrl, '_blank');

    // Limpiar formulario
    document.getElementById('contactForm').reset();
    showSuccessMessage('Mensaje enviado a WhatsApp. Nos pondremos en contacto pronto.');
}

// ===================================
// MENSAJES
// ===================================

function showWelcomeMessage() {
    const message = document.createElement('div');
    message.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #059669 0%, #10b981 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 0.75rem;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        z-index: 1000;
        animation: slideInRight 0.5s ease-out;
    `;
    message.innerHTML = `
        <h3 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">¡Bienvenido a Sentido de Vida!</h3>
        <p style="margin: 0; font-size: 0.95rem;">Estamos aquí para apoyarte en tu camino hacia la recuperación. Cada semana, un nuevo tema para educarte y concientizar.</p>
    `;
    document.body.appendChild(message);

    setTimeout(() => {
        message.style.opacity = '0';
        message.style.transition = 'opacity 0.5s ease-out';
        setTimeout(() => message.remove(), 500);
    }, 5000);
}

function showErrorMessage(text) {
    const message = document.createElement('div');
    message.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
        color: white;
        padding: 1rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    `;
    message.textContent = text;
    document.body.appendChild(message);

    setTimeout(() => {
        message.style.opacity = '0';
        message.style.transition = 'opacity 0.5s ease-out';
        setTimeout(() => message.remove(), 500);
    }, 4000);
}

function showSuccessMessage(text) {
    const message = document.createElement('div');
    message.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #059669 0%, #10b981 100%);
        color: white;
        padding: 1rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        z-index: 1000;
    `;
    message.textContent = text;
    document.body.appendChild(message);

    setTimeout(() => {
        message.style.opacity = '0';
        message.style.transition = 'opacity 0.5s ease-out';
        setTimeout(() => message.remove(), 500);
    }, 4000);
}

// ===================================
// SCROLL SUAVE
// ===================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ===================================
// INICIAR APP
// ===================================

document.addEventListener('DOMContentLoaded', loadData);

// ===================================
// FUNCIONES DE UTILIDAD
// ===================================

// Detectar si es primera visita y mostrar modal de bienvenida
function isFirstVisit() {
    return !localStorage.getItem('visited');
}

// Compartir en redes sociales
function shareOnSocial(platform) {
    const week = weeksData[currentWeek - 1];
    const text = `Semana ${currentWeek}: ${week.title} - ${week.subtitle}. Aprende sobre adicciones y salud mental con Sentido de Vida GDL.`;
    const url = window.location.href;

    let shareUrl = '';
    switch(platform) {
        case 'facebook':
            shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
            break;
        case 'twitter':
            shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
            break;
        case 'whatsapp':
            shareUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`;
            break;
    }

    if (shareUrl) {
        window.open(shareUrl, '_blank', 'width=600,height=400');
    }
}

// Analytics simple
function trackEvent(eventName, eventData) {
    console.log(`Event: ${eventName}`, eventData);
    // Aquí puedes integrar Google Analytics o similar
}
