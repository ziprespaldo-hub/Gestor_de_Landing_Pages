# Landing Page - Clínica en Adicciones Sentido de Vida GDL

## 📋 Descripción

Landing page estática, emocionalmente impactante y educativa para la Clínica en Adicciones Sentido de Vida GDL. Diseñada para ser actualizada semanalmente con nuevos temas sobre adicciones, salud mental y recuperación.

## 🎯 Características

- ✅ **100% HTML/CSS/JavaScript** - Sin dependencias, hosting económico
- ✅ **52 Temas Semanales** - Estructura completa para un año
- ✅ **Diseño Responsivo** - Funciona en todos los dispositivos
- ✅ **Fácil de Actualizar** - Solo edita `data.json`
- ✅ **Emocionalmente Impactante** - Diseño profesional y cálido
- ✅ **Inclusivo** - Dirigido a hombres pero abierto a todos
- ✅ **Llamadas a Acción Claras** - WhatsApp, teléfono, formulario

## 📁 Estructura de Archivos

```
landing-page-sentido-vida/
├── index.html              # Página principal
├── data.json               # Base de datos de 52 temas
├── README.md               # Este archivo
└── assets/
    ├── css/
    │   └── styles.css      # Estilos CSS
    └── js/
        └── script.js       # JavaScript interactivo
```

## 🚀 Cómo Usar

### 1. Descargar y Abrir
- Descarga todos los archivos
- Abre `index.html` en tu navegador
- ¡Listo! La página está funcionando

### 2. Actualizar Semanalmente

Cada semana, edita `data.json`:

```json
{
  "week": 1,
  "title": "¿Qué es la adicción?",
  "subtitle": "Cerebro y enfermedad",
  "description": "La adicción no es un fracaso moral...",
  "keyPoints": [
    "La adicción es una enfermedad neurobiológica",
    "Afecta el sistema de recompensa del cerebro",
    "No es debilidad, es química cerebral",
    "La recuperación es posible con ayuda profesional"
  ],
  "cta": "Conoce más sobre cómo podemos ayudarte",
  "quarter": "Primer Trimestre: Cimientos y Realidad"
}
```

**Solo necesitas cambiar:**
- `title` - Título del tema
- `subtitle` - Subtítulo
- `description` - Descripción principal
- `keyPoints` - Lista de puntos clave
- `cta` - Llamada a acción
- `quarter` - Trimestre (si corresponde)

### 3. Personalizar Datos de la Institución

En `data.json`, edita la sección `institution`:

```json
"institution": {
  "name": "Clínica en Adicciones Sentido de Vida GDL",
  "phone": "+33 3196 2135",
  "email": "terehernandez2000@gmail.com",
  "facebook": "https://www.facebook.com/...",
  "whatsapp": "https://wa.me/3331962135"
}
```

## 🎨 Personalización

### Cambiar Colores

En `assets/css/styles.css`, busca `:root` y edita:

```css
:root {
    --primary: #1e40af;        /* Azul profundo */
    --secondary: #059669;      /* Verde salvia */
    --accent: #d97706;         /* Ámbar */
}
```

### Cambiar Tipografía

En `index.html`, busca la sección de Google Fonts y cambia:

```html
<link href="https://fonts.googleapis.com/css2?family=TU_FUENTE&display=swap" rel="stylesheet">
```

## 📱 Responsive Design

La página se adapta automáticamente a:
- 📱 Móviles (320px+)
- 📱 Tablets (768px+)
- 💻 Desktop (1024px+)

## 🔧 Hosting Recomendado

### Opciones Económicas:
1. **GitHub Pages** - Gratis, muy fácil
2. **Netlify** - Gratis, con dominio personalizado
3. **Vercel** - Gratis, muy rápido
4. **Hosting compartido** - $2-5 USD/mes

### Pasos para GitHub Pages:
1. Crea un repositorio en GitHub
2. Sube todos los archivos
3. Ve a Settings → Pages
4. Selecciona "Deploy from branch"
5. ¡Listo! Tu página está en línea

## 🔐 Privacidad y Seguridad

- ✅ No hay base de datos
- ✅ No se recopilan datos personales
- ✅ Formulario de contacto usa WhatsApp (tu control)
- ✅ Cumple con privacidad de datos

## 📊 Funcionalidades

### Navegación Semanal
- Botones Anterior/Siguiente
- Slider para seleccionar semana
- Teclado (flechas izquierda/derecha)
- Guardado automático de semana actual

### Contacto
- Teléfono directo
- WhatsApp integrado
- Formulario que envía a WhatsApp
- Email de contacto

### Redes Sociales
- Links a Facebook, Instagram, TikTok
- Botones de compartir

## 💡 Consejos para Máximo Impacto

1. **Contenido Emocional** - Usa historias (anónimas) cuando sea posible
2. **Llamadas a Acción Claras** - Cada sección debe tener un CTA
3. **Actualización Consistente** - Cada semana, sin falta
4. **Promoción** - Comparte en redes sociales cada semana
5. **Feedback** - Pide comentarios para mejorar

## 🆘 Soporte

Si necesitas ayuda:
- Revisa el código comentado en `script.js`
- Verifica que `data.json` esté bien formado (JSON válido)
- Abre la consola del navegador (F12) para ver errores

## 📄 Licencia

Libre para usar y modificar. Hecho con ❤️ para Sentido de Vida GDL.

---

**Última actualización:** Diciembre 2025
**Versión:** 1.0
